"""
Sample Python Programs

This module contains various sample Python functions and classes demonstrating
different concepts like divisibility checks, leap year, password validation,
grading system, username validation, exception handling, and ATM functionality.
"""


def is_divisible(num):
    """
    Checks if a number is divisible by 5, 3, both, or neither.

    Args:
        num (int): The number to check.

    Returns:
        str: The divisibility result.
    """
    if num % 5 == 0 and num % 3 == 0:
        return "Divisible by both 5 and 3"
    elif num % 5 == 0:
        return "Divisible by 5"
    elif num % 3 == 0:
        return "Divisible by 3"
    else:
        return "Not divisible by either 5 or 3"


number = int(input("Enter a number: "))
result = is_divisible(number)
print(result)


def is_leap_year(year):
    """
    Checks if a year is a leap year.

    Args:
        year (int): The year to check.

    Returns:
        bool: True if leap year, False otherwise.
    """
    if (year % 4 == 0 and year % 100 != 0) or (year % 400 == 0):
        return True
    else:
        return False


year = int(input("Enter a year: "))
result = is_leap_year(year)
print(f"The year {year} is {'a leap year' if result else 'not a leap year'}.")


def password_check(password):
    """
    Checks if a password is at least 8 characters long.

    Args:
        password (str): The password to check.

    Returns:
        str: Validation result.
    """
    if len(password) < 8:
        return "Password is less than 8 characters."
    else:
        return "Password is valid."


password = input("Enter a password: ")
result = password_check(password)
print(result)


def grade(marks):
    """
    Calculates the grade based on average marks for 5 subjects.

    Args:
        marks (list): List of 5 marks.

    Returns:
        str: The grade.
    """
    average = sum(marks) / len(marks)
    if average >= 90:
        return "Grade A"
    elif average >= 80:
        return "Grade B"
    elif average >= 70:
        return "Grade C"
    elif average >= 60:
        return "Grade D"
    else:
        return "Grade F"


marks = []
for i in range(5):
    mark = int(input(f"Enter marks for subject {i+1}: "))
    marks.append(mark)
result = grade(marks)
print(result)


def validate_username(username):
    """
    Validates a username based on length and format requirements.

    Args:
        username (str): The username to validate.

    Returns:
        str: Validation result.
    """
    if len(username) < 5:
        return "Username must be at least 5 characters long."
    if "@" not in username or "." not in username:
        return "Username must contain '@' and '.'."
    if not (username.endswith(".com") or username.endswith(".in") or username.endswith(".org")):
        return "Username must end with '.com', '.in', or '.org'."
    return "Username is valid."


username = input("Enter a username: ")
result = validate_username(username)
print(result)


def validate_password(password):
    """
    Validates a password for length and character requirements.

    Args:
        password (str): The password to validate.

    Returns:
        str: Validation result.
    """
    if len(password) < 8:
        return "Password must be at least 8 characters long."
    has_upper = any(char.isupper() for char in password)
    has_lower = any(char.islower() for char in password)
    has_digit = any(char.isdigit() for char in password)
    has_special = any(not char.isalnum() for char in password)
    if not has_upper:
        return "Password must contain at least one uppercase letter."
    if not has_lower:
        return "Password must contain at least one lowercase letter."
    if not has_digit:
        return "Password must contain at least one digit."
    if not has_special:
        return "Password must contain at least one special character."
    return "Password is valid."


password = input("Enter a password: ")
result = validate_password(password)
print(result)


def divide_numbers(a, b):
    """
    Divides two numbers with exception handling.

    Args:
        a (float): Numerator.
        b (float): Denominator.

    Returns:
        float or str: The result or error message.
    """
    try:
        result = a / b
        return result
    except ZeroDivisionError:
        return "Cannot divide by zero."
    except ValueError:
        return "Invalid input. Please enter numbers."


num1 = int(input("Enter first number: "))
num2 = int(input("Enter second number: "))
result = divide_numbers(num1, num2)
print(result)


class ATM:
    """
    Represents an ATM account with basic banking operations.
    """

    def __init__(self, balance=0):
        """
        Initializes the ATM account with a balance.

        Args:
            balance (float): Initial balance.
        """
        self.balance = balance

    def deposit(self, amount):
        """
        Deposits money into the account.

        Args:
            amount (float): Amount to deposit.

        Returns:
            str: Deposit confirmation with new balance.
        """
        self.balance += amount
        return f"Deposited {amount}. Current balance: {self.balance}"

    def withdraw(self, amount):
        """
        Withdraws money from the account if sufficient balance.

        Args:
            amount (float): Amount to withdraw.

        Returns:
            str: Withdrawal result.
        """
        if amount > self.balance:
            return "Insufficient balance."
        self.balance -= amount
        return f"Withdrew {amount}. Current balance: {self.balance}"

    def check_balance(self):
        """
        Checks the current balance.

        Returns:
            str: Current balance.
        """
        return f"Current balance: {self.balance}"

    def transfer(self, amount, recipient):
        """
        Transfers money to another account if sufficient balance.

        Args:
            amount (float): Amount to transfer.
            recipient (ATM): The recipient account.

        Returns:
            str: Transfer result.
        """
        if amount > self.balance:
            return "Insufficient balance."
        self.balance -= amount
        recipient.balance += amount
        return f"Transferred {amount} to recipient. Current balance: {self.balance}"

    def change_pin(self, old_pin, new_pin):
        """
        Changes the PIN (placeholder implementation).

        Args:
            old_pin (str): Old PIN.
            new_pin (str): New PIN.

        Returns:
            str: Change result.
        """
        # This is a placeholder for pin change functionality
        return "Pin changed successfully."


account1 = ATM(1000)
account2 = ATM(500)
print(account1.deposit(200))
print(account1.withdraw(300))
print(account1.check_balance())
print(account1.transfer(400, account2))
print(account1.check_balance())
print(account2.check_balance())

