# file_comment_added: loop.py
# Purpose: Annotate and document the code blocks in loop.py.
# Note: comments inserted automatically for learning and review.

#print numbers from 1 to 5
# Control block: for i in range(1, 6):
for i in range(1, 6):
# Action call: print(i)
    print(i)

#find the sum of first 10 natural numbers
# Assignment / update: sum=0
sum=0
# Control block: for i in range(1, 11):
for i in range(1, 11):
# Assignment / update: sum+=i
    sum+=i
# Action call: print("The sum of first 10 natural numbers is:", sum)
print("The sum of first 10 natural numbers is:", sum)

#print even numbers from 1 to 10 using range
# Control block: for i in range(2, 11, 2):
for i in range(2, 11, 2):
# Action call: print(i)
    print(i)

#print even numbers from 1 to 10 using range and if condition
# Control block: for i in range(1, 11):
for i in range(1, 11):
# Control block: if i%2==0:
    if i%2==0:
# Action call: print(i)
        print(i)

#print odd numbers from 1 to 10 using range
# Control block: for i in range(1, 11, 2):
for i in range(1, 11, 2):
# Action call: print(i)
    print(i)

#print odd numbers from 1 to 10 using range and if condition
# Control block: for i in range(1, 11):
for i in range(1, 11):      
# Control block: if i%2!=0:
    if i%2!=0:
# Action call: print(i)
        print(i)

#print multiplication table of a number
# Assignment / update: num=int(input("Enter a number to print its multiplication: "))
num=int(input("Enter a number to print its multiplication: "))
# Control block: for i in range(1, 11):
for i in range(1, 11):
# Action call: print(num, "x", i, "=", num*i)
    print(num, "x", i, "=", num*i)

#print 1 to 5 usind while loop
# Assignment / update: i=1
i=1
# Control block: while i<=5:
while i<=5:
# Action call: print(i)
    print(i)
# Assignment / update: i+=1
    i+=1

#pattern printing right-angled triangle
# Assignment / update: n=int(input("Enter the number of rows: "))
n=int(input("Enter the number of rows: "))  
# Control block: for i in range(1, n+1):
for i in range(1, n+1):
# Action call: print("* " * i)
    print("* " * i)


#printing equilateral triangle pattern
# Assignment / update: n=int(input("Enter the number of rows: "))
n=int(input("Enter the number of rows: "))
# Control block: for i in range(1, n+1):
for i in range(1, n+1):
# Action call: print(" " * (n - i) + "* " * i)
    print(" " * (n - i) + "* " * i)

#simple example of nested loop
# Assignment / update: n=int(input("Enter the number of rows: "))
n=int(input("Enter the number of rows: "))
# Control block: for i in range(1, n+1):
for i in range(1, n+1):
# Control block: for j in range(1, i+1):
    for j in range(1, i+1):
# Action call: print(i,j)
        print(i,j)

#nested loop to print numbers in equilateral triangle pattern
# Assignment / update: n=int(input("Enter the number of rows: "))
n=int(input("Enter the number of rows: "))
# Control block: for i in range(1, n+1):
for i in range(1, n+1):
# Action call: print(" " * (n - i), end="")
    print(" " * (n - i), end="")
# Control block: for j in range(1, i+1):
    for j in range(1, i+1):
# Action call: print(j, end=" ")
        print(j, end=" ")
# Action call: print()
    print()
