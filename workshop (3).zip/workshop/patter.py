# file_comment_added: patter.py
# Purpose: Annotate and document the code blocks in patter.py.
# Note: comments inserted automatically for learning and review.


#pattern printing right-angled triangle
# Assignment / update: n=int(input("Enter the number of rows: "))
n=int(input("Enter the number of rows: "))  
# Control block: for i in range(1, n+1):
for i in range(1, n+1):
# Action call: print("* " * i)
    print("* " * i)

#printing equilateral triangle pattern
# Assignment / update: n=int(input("Enter the number of rows: "))
n=int(input("Enter the number of rows: "))
# Control block: for i in range(1, n+1):
for i in range(1, n+1):
# Action call: print(" " * (n - i) + "* " * i)
    print(" " * (n - i) + "* " * i)

#simple example of nested loop
# Assignment / update: n=int(input("Enter the number of rows: "))
n=int(input("Enter the number of rows: "))
# Control block: for i in range(1, n+1):
for i in range(1, n+1):
# Control block: for j in range(1, i+1):
    for j in range(1, i+1):
# Action call: print(i,j)
        print(i,j)

#nested loop to print numbers in equilateral triangle pattern
# Assignment / update: n=int(input("Enter the number of rows: "))
n=int(input("Enter the number of rows: "))
# Control block: for i in range(1, n+1):
for i in range(1, n+1):
# Action call: print(" " * (n - i), end="")
    print(" " * (n - i), end="")
# Control block: for j in range(1, i+1):
    for j in range(1, i+1):
# Action call: print(j, end=" ")
        print(j, end=" ")
# Action call: print()
    print()

#pattern printing diamond
# Assignment / update: n=int(input("Enter the number of rows: "))
n=int(input("Enter the number of rows: "))
# Control block: for i in range(1, n+1):
for i in range(1, n+1):
# Action call: print(" " * (n - i) + "* " * i)
    print(" " * (n - i) + "* " * i)
# Control block: for i in range(n-1, 0, -1):
for i in range(n-1, 0, -1):
# Action call: print(" " * (n - i) + "* " * i)
    print(" " * (n - i) + "* " * i)

#pattern printing hollow square
# Assignment / update: n=int(input("Enter the number of rows: "))
n=int(input("Enter the number of rows: "))
# Control block: for i in range(1, n+1):
for i in range(1, n+1):
# Control block: if i==1 or i==n:
    if i==1 or i==n:
# Action call: print("* " * n)
        print("* " * n)
# Control block: else:
    else:
# Action call: print("* " + "  " * (n-2) + "* ")
        print("* " + "  " * (n-2) + "* ")

#pattern printing hollow right-angled triangle
# Assignment / update: n=int(input("Enter the number of rows: "))
n=int(input("Enter the number of rows: "))  
# Control block: for i in range(1, n+1):
for i in range(1, n+1):
# Control block: if i==1 or i==n:
    if i==1 or i==n:
# Action call: print("* " * i)
        print("* " * i)
# Control block: else:
    else:
# Action call: print("* " + "  " * (i-2) + "* ")
        print("* " + "  " * (i-2) + "* ")

#printing hourglass pattern
# Assignment / update: n=int(input("Enter the number of rows: "))
n=int(input("Enter the number of rows: "))
# Control block: for i in range(n, 0, -1):
for i in range(n, 0, -1):
# Action call: print(" " * (n - i) + "* " * i)
    print(" " * (n - i) + "* " * i)
# Control block: for i in range(2, n+1):
for i in range(2, n+1):
# Action call: print(" " * (n - i) + "* " * i)
    print(" " * (n - i) + "* " * i)

#printing star pattern
# Assignment / update: n=int(input("Enter the number of rows: "))
n=int(input("Enter the number of rows: "))
# Control block: for i in range(1, n+1):
for i in range(1, n+1):
# Action call: print(" " * (n - i) + "* " * (2*i-1))
    print(" " * (n - i) + "* " * (2*i-1))
    
