"""
Comment Annotation Script

This script automatically adds verbose comments to Python files in the workshop folder
for learning and review purposes. It annotates functions, classes, control blocks, assignments, and operations.
"""

import pathlib, re
root = pathlib.Path(r'c:/Users/Admin/Desktop/workshop')
for file in sorted(root.glob('*.py')):
    if file.name == 'annotate_comments.py':
        continue
    text = file.read_text(encoding='utf8')
    lines = text.splitlines()
    if lines and lines[0].startswith('# file_comment_added:'):
        continue
    new_lines = [
        f"# file_comment_added: {file.name}",
        f"# Purpose: Annotate and document the code blocks in {file.name}.",
        "# Note: comments inserted automatically for learning and review.",
        "",
    ]
    for line in lines:
        stripped = line.strip()
        if not stripped or stripped.startswith('#'):
            new_lines.append(line)
            continue
        m = re.match(r'def\s+(\w+)\s*\(', stripped)
        if m:
            new_lines.append(f"# Function '{m.group(1)}' definition")
            new_lines.append(line)
            continue
        m = re.match(r'class\s+(\w+)\s*\b', stripped)
        if m:
            new_lines.append(f"# Class '{m.group(1)}' definition")
            new_lines.append(line)
            continue
        if re.match(r'(if|elif|else|for|while|try|except|finally|with)\b', stripped):
            new_lines.append(f"# Control block: {stripped}")
            new_lines.append(line)
            continue
        if '=' in line and not stripped.startswith(('==', '>=', '<=', '!=', 'return', 'print', 'raise', 'assert')):
            new_lines.append(f"# Assignment / update: {stripped}")
            new_lines.append(line)
            continue
        if re.match(r'(print|input|return|yield|raise)\b', stripped):
            new_lines.append(line)
            continue
        new_lines.append(f"# Operation: {stripped}")
        new_lines.append(line)
    file.write_text('\n'.join(new_lines) + '\n', encoding='utf8')
    print(f'Annotated: {file.name}')
