"""
Data Structures Demonstration

This module demonstrates various Python data structures:
dictionaries, tuples, sets, nested structures, and basic file handling.
"""

# Dictionary basics
student = {"name": "Deekshith", "age": 20}
print(student["name"])
print(student["age"])
print("\n")

# Update and add
student["age"] = 26
student["city"] = "Bangalore"
print(student)
print("\n")

print(student.get("name"))
print(student.get("age"))
print("\n")

# Loop through
for key, value in student.items():
    print(key, ":", value)
print("only through keys and values:\n")

# Loop through keys
for key in student.keys():
    print(key)
print("only through keys:\n")

# Loop through values
for value in student.values():
    print(value)
print("only through values:\n")

# Delete a key-value pair
del student["age"]
print(student)
print("\n")

# Check if a key exists
if "name" in student:
    print("Name exists in the dictionary.")
if "age" not in student:
    print("Age does not exist in the dictionary.")
print("\n")

# Dictionary methods
print(student.keys())
print(student.values())
print(student.items())
print(student.get("name"))
print(student.get("age", "Age not found"))
print("\n")

# Clear the dictionary
student.clear()
print(student)
print("\n")

# Repopulate the dictionary
student["name"] = "Deekshith"
student["age"] = 20
print(student)
print("\n")

# Copying a dictionary
student_copy = student.copy()
print(student_copy)
print("\n")

# Nested dictionary
students = {
    "student1": {"name": "Deekshith", "age": 20},
    "student2": {"name": "Alice", "age": 22}
}
print(students["student1"]["name"])
print(students["student2"]["age"])
print("\n")

# Creating a tuple
fruits = ("apple", "banana", "cherry")
print(fruits)
print("\n")

# Accessing tuple elements
print(fruits[0])
print(fruits[1])
print(fruits[2])
print("\n")

# Count elements
print(len(fruits))
print(fruits.count("apple"))
print(fruits.count("banana"))
print(fruits.count("cherry"))

# Set operations
set1 = {1, 2, 3, 4}
set2 = {3, 4, 5, 6}
a = set1 & set2  # Intersection
b = set1 | set2  # Union
c = set1 - set2  # Difference
print("Intersection:", a)
print("Union:", b)
print("Difference:", c)

# Set methods
print("Union:", set1.union(set2))
print("Intersection:", set1.intersection(set2))
print("Difference:", set1.difference(set2))

# Dictionary for student marks
students = {
    "Alice": [85, 90],
    "Bob": [92],
    "Charlie": [78]
}
# Print name and marks
for name, marks in students.items():
    print(name, ":", marks)

# Add marks
students["Alice"].append(95)
print(students["Alice"])

# Add new student
students["David"] = [88]
print(students)

# Nested dictionary
students = {
    "Deekshith": {"marks": [85, 90], "faculty": {"Math": "Dr. Smith", "Science": "Dr. Johnson"}},
    "Antony": {"marks": [92], "faculty": {"Math": "Dr. Smith"}},
    "Charlie": {"marks": [78], "faculty": {"Science": "Dr. Johnson"}}
}
print(students["Deekshith"]["marks"])
print(students["Antony"]["faculty"]["Math"])
print("\n")

print(students.keys())
print(students.values())

# Remove duplicates from list using set
my_list = [1, 2, 3, 2, 4, 1, 5]
unique_list = list(set(my_list))
print(unique_list)

# Association members
association_members = {"neelam": "president", "deekshith": "vice president", "trisha": "secretary", "sneha": "treasurer"}
print(association_members["neelam"])
print(association_members["deekshith"])
print(association_members.keys())
print(association_members.values())

# Fruits and colors
fruits_colors = {"apple": "red", "banana": "yellow", "cherry": "red", "grape": "purple"}
print(fruits_colors["apple"])
print(fruits_colors["banana"])
print(fruits_colors.keys())
print(fruits_colors.values())

# Add new fruit
fruits_colors["orange"] = "orange"
print(fruits_colors)

# Remove fruit
del fruits_colors["grape"]
print(fruits_colors)

# Check if fruit exists
if "cherry" in fruits_colors:
    print("Cherry is in the dictionary.")
else:
    print("Cherry is not in the dictionary.")

# Loop through
for fruit, color in fruits_colors.items():
    print(fruit, ":", color)

# Set check and add
my_set = {1, 2, 3, 4}
element = int(input("Enter an element to check: "))
if element in my_set:
    print(f"{element} exists in the set.")
else:
    print(f"{element} does not exist in the set.")
my_set.add(element)
print(f"{element} has been added to the set.")
print(my_set)

# File handling
# Writing to a file
with open("example.txt", "w") as file:
    file.write("Hello, this is a sample file.\n")
    file.write("This file is used for demonstrating file handling in Python.\n")

# Reading from a file
with open("example.txt", "r") as file:
    content = file.read()
    print(content)

# Appending to a file
with open("example.txt", "a") as file:
    file.write("This line is appended to the file.\n")

# Reading the updated file
with open("example.txt", "r") as file:
    content = file.read()
    print(content)

# Deleting a file
import os
os.remove("example.txt")

