# file_comment_added: pratice.py
# Purpose: Annotate and document the code blocks in pratice.py.
# Note: comments inserted automatically for learning and review.

#add 2 numbvers using input
# Assignment / update: a=int(input("Enter a number: "))
a=int(input("Enter a number: "))
# Assignment / update: b=int(input("Enter another number: "))
b=int(input("Enter another number: "))
# Assignment / update: sum=a+b
sum=a+b
# Action call: print("The sum of", a, "and", b, "is", sum)
print("The sum of", a, "and", b, "is", sum)
# Action call: print("\n")
print("\n")

#area of circle using radius as input   
# Assignment / update: radius=float(input("Enter the radius of the circle: "))
radius=float(input("Enter the radius of the circle: "))
# Assignment / update: area=3.14*radius*radius
area=3.14*radius*radius
# Action call: print("The area of the circle with radius", radius, "is", area)
print("The area of the circle with radius", radius, "is", area)
# Action call: print("\n")
print("\n")

#square and cube of a number
# Assignment / update: num=int(input("Enter a number: "))
num=int(input("Enter a number: "))
# Action call: print("The square of", num, "is", num**2)
print("The square of", num, "is", num**2)
# Action call: print("The cube of", num, "is", num**3)
print("The cube of", num, "is", num**3)
# Action call: print("\n")
print("\n")

#area of rectangle using length and breadth as input
# Assignment / update: length=float(input("Enter the length of the rectangle: "))
length=float(input("Enter the length of the rectangle: "))
# Assignment / update: breadth=float(input("Enter the breadth of the rectangle: "))
breadth=float(input("Enter the breadth of the rectangle: "))
# Assignment / update: area=length*breadth
area=length*breadth
# Action call: print("The area of the rectangle with length", length, "and breadth", breadth, "is", area)
print("The area of the rectangle with length", length, "and breadth", breadth, "is", area)
# Action call: print("\n")
print("\n")

#take 2 numbers as input and print their product and division
# Assignment / update: num1=float(input("Enter a number: "))
num1=float(input("Enter a number: "))   
# Assignment / update: num2=float(input("Enter another number: "))
num2=float(input("Enter another number: "))
# Assignment / update: product=num1*num2
product=num1*num2
# Control block: if num2!=0:
if num2!=0:
# Assignment / update: division=num1/num2
    division=num1/num2
# Action call: print("The product of", num1, "and", num2, "is", product)
    print("The product of", num1, "and", num2, "is", product)
# Action call: print("The division of", num1, "by", num2, "is", division)
    print("The division of", num1, "by", num2, "is", division)
# Action call: print("\n")
    print("\n")
# Control block: else:
else:
# Action call: print("The product of", num1, "and", num2, "is", product)
    print("The product of", num1, "and", num2, "is", product)
# Action call: print("Division by zero is not allowed.")
    print("Division by zero is not allowed.")
# Action call: print("\n")
    print("\n")

# convert temperature from Celsius to Fahrenheit
# Assignment / update: celsius=float(input("Enter temperature in Celsius: "))
celsius=float(input("Enter temperature in Celsius: "))
# Assignment / update: fahrenheit=(celsius*9/5)+32
fahrenheit=(celsius*9/5)+32
# Action call: print(celsius, "degrees Celsius is equal to", fahrenheit, "degrees Fahrenheit.")
print(celsius, "degrees Celsius is equal to", fahrenheit, "degrees Fahrenheit.")
# Action call: print("\n")
print("\n")

#take price and quantity as input and calculate total cost
# Assignment / update: price=float(input("Enter the price of the item: "))
price=float(input("Enter the price of the item: "))
# Assignment / update: quantity=int(input("Enter the quantity: "))
quantity=int(input("Enter the quantity: "))
# Assignment / update: total_cost=price*quantity
total_cost=price*quantity
# Action call: print("The total cost is:", total_cost)
print("The total cost is:", total_cost)
# Action call: print("\n")
print("\n")

#take marks of 5 subject out of 100 and calculate percentage
# Assignment / update: total_marks=0
total_marks=0
# Control block: for i in range(1, 6):
for i in range(1, 6):
# Assignment / update: marks=int(input("Enter marks for subject " + str(i) + " (out of 100): "))
    marks=int(input("Enter marks for subject " + str(i) + " (out of 100): "))
# Control block: if marks<0 or marks>100:
    if marks<0 or marks>100:
# Action call: print("Invalid marks entered.")
        print("Invalid marks entered.")
# Operation: exit()
        exit()
# Control block: else:
    else:
# Assignment / update: total_marks+=marks
        total_marks+=marks
# Assignment / update: percentagee=(total_marks/500)*100
percentagee=(total_marks/500)*100
# Action call: print("The percentage is:", percentagee)
print("The percentage is:", percentagee)

#taking the number of students and their name and 5 subject marks(english, mathematics, science, social studies, hindi) as input and calculating percentage for each student and printing it along with the order of students based on their percentage
# Assignment / update: num_students=int(input("Enter the number of students: "))
num_students=int(input("Enter the number of students: "))
# Assignment / update: students=[]
students=[]
# Control block: for i in range(num_students):
for i in range(num_students):
# Assignment / update: name=input("Enter the name of student " + str(i+1) + ": ")
    name=input("Enter the name of student " + str(i+1) + ": ")
# Assignment / update: total_mmarks=0
    total_mmarks=0
# Control block: for j in range(1, 6):
    for j in range(1, 6):
# Assignment / update: mmarks=int(input("Enter marks for subject " + str(j) + " (out of 100): "))
        mmarks=int(input("Enter marks for subject " + str(j) + " (out of 100): "))
# Control block: if mmarks<0 or mmarks>100:
        if mmarks<0 or mmarks>100:
# Action call: print("Invalid marks entered.")
            print("Invalid marks entered.")
# Operation: exit()
            exit()
# Control block: else:
        else:
# Assignment / update: total_mmarks+=mmarks
            total_mmarks+=mmarks
# Assignment / update: percentage=(total_mmarks/500)*100
    percentage=(total_mmarks/500)*100
# Operation: students.append((name, percentage))
    students.append((name, percentage))
# Assignment / update: students.sort(key=lambda x: x[1], reverse=True)
students.sort(key=lambda x: x[1], reverse=True)
# Action call: print("\nStudent Name\tPercentage")
print("\nStudent Name\tPercentage")
# Control block: for name, percentage in students:
for name, percentage in students:
# Action call: print(f"{name}\t{percentage:.2f}%")
    print(f"{name}\t{percentage:.2f}%")



