"""
Dictionary Operations

This module demonstrates basic dictionary operations in Python:
creating, accessing, modifying, adding, removing, and iterating.
"""

# Create a dictionary
student = {"name": "Alice", "age": 20, "grade": "A"}

# Access values
print(student["name"])  # Output: Alice
print(student["age"])   # Output: 20
print(student["grade"]) # Output: A

# Modify values
student["age"] = 21
print(student)  # Output: {'name': 'Alice', 'age': 21, 'grade': 'A'}

# Add new key-value pair
student["major"] = "Computer Science"
print(student)  # Output: {'name': 'Alice', 'age': 21, 'grade': 'A', 'major': 'Computer Science'}

# Remove a key-value pair
del student["grade"]
print(student)  # Output: {'name': 'Alice', 'age': 21, 'major': 'Computer Science'}

# Iterate through the dictionary
for key, value in student.items():
    print(key, value)
# Output:
# name Alice
# age 21
# major Computer Science
