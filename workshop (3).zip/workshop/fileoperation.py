"""
File Operations Demonstration

This module demonstrates basic file operations in Python: reading, writing, appending,
and using context managers for file handling.
"""

# Reading from a file
f = open("deekshith.txt", "r")
print(f.read())
f.close()

# Writing to a file
f = open("deekshith.txt", "w")
f.write("Hello world!")
f.close()

# Appending to a file
f = open("deekshith.txt", "a")
f.write("\nNew line added.")
f.close()

f = open("deekshith.txt", "a")
f.write("\nAnother line added.")
f.close()

# Reading with context manager
with open("deekshith.txt", "r") as f:
    print(f.read())

# Writing and reading "Hello Python" using context manager
with open("hello.txt", "w") as f:
    f.write("Hello Python!")

with open("hello.txt", "r") as f:
    print(f.read())

# Appending to hello.txt
with open("hello.txt", "a") as f:
    f.write("\nDeekshith")

with open("hello.txt", "r") as f:
    print(f.read())
