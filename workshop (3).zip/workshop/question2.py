# file_comment_added: question2.py
# Purpose: Annotate and document the code blocks in question2.py.
# Note: comments inserted automatically for learning and review.

#print first,last and middle character of a string
# Assignment / update: s=input("Enter a string: ")
s=input("Enter a string: ")
# Assignment / update: first_char=s[0]
first_char=s[0]
# Assignment / update: last_char=s[-1]
last_char=s[-1]
# Assignment / update: middle_char=s[len(s)//2]
middle_char=s[len(s)//2]
# Action call: print("First character:", first_char)
print("First character:", first_char)
# Action call: print("Last character:", last_char)
print("Last character:", last_char)
# Action call: print("Middle character:", middle_char)
print("Middle character:", middle_char)
# Action call: print(first_char+" "+last_char+" "+middle_char)
print(first_char+" "+last_char+" "+middle_char)

#combining two strings
# Assignment / update: s1=input("Enter first string: ")
s1=input("Enter first string: ")
# Assignment / update: s2=input("Enter second string: ")
s2=input("Enter second string: ")
# Assignment / update: combined_string=s1+" "+s2
combined_string=s1+" "+s2
# Action call: print("Combined string:", combined_string)
print("Combined string:", combined_string)

#reversing the combined string
# Assignment / update: combined_string1=combined_string[::-1]
combined_string1=combined_string[::-1]
# Assignment / update: combined_string2=s2+" "+s1
combined_string2=s2+" "+s1
# Action call: print("Combined string in reverse by words:", combined_string2)
print("Combined string in reverse by words:", combined_string2)
# Action call: print("Combined string in reverse by letters:", combined_string1)
print("Combined string in reverse by letters:", combined_string1)

#another method to reverse using reverse keyword
# Assignment / update: reversed_text="".join(reversed(combined_string))
reversed_text="".join(reversed(combined_string))
# Action call: print(reversed_text)
print(reversed_text)

#other method to reverse using loop
# Assignment / update: reversed_string=""
reversed_string=""
# Control block: for char in combined_string:
for char in combined_string:
# Assignment / update: reversed_string=char + reversed_string
    reversed_string=char + reversed_string
# Action call: print(reversed_string)
print(reversed_string)

#other method to reverse using recursion
# Function 'reverse_string' definition
def reverse_string(s):  
# Control block: if len(s) == 0:
    if len(s) == 0:
# Action call: return s
        return s
# Control block: else:
    else:
# Action call: return reverse_string(s[1:]) + s[0]
        return reverse_string(s[1:]) + s[0]
# Assignment / update: reversed_string2=reverse_string(combined_string)
reversed_string2=reverse_string(combined_string)
# Action call: print(reversed_string2)
print(reversed_string2)

#other method to reverse using stack
# Function 'reverse_string_stack' definition
def reverse_string_stack(s):
# Assignment / update: stack=[]
    stack=[]
# Control block: for char in s:
    for char in s:
# Operation: stack.append(char)
        stack.append(char)
# Assignment / update: reversed_string=""
    reversed_string=""
# Control block: while stack:
    while stack:
# Assignment / update: reversed_string+=stack.pop()
        reversed_string+=stack.pop()
# Action call: return reversed_string
    return reversed_string
# Assignment / update: reversed_string3=reverse_string_stack(combined_string)
reversed_string3=reverse_string_stack(combined_string)
# Action call: print(reversed_string3)
print(reversed_string3) 

#other method to reverse using list comprehension
# Assignment / update: reversed_string4="".join([combined_string[i] for i in range(len(combined_string)-1, -1, -1)])
reversed_string4="".join([combined_string[i] for i in range(len(combined_string)-1, -1, -1)])
# Action call: print(reversed_string4)
print(reversed_string4) 

#other method to reverse using built-in function
# Assignment / update: reversed_string5="".join(reversed(combined_string))
reversed_string5="".join(reversed(combined_string))
# Action call: print(reversed_string5)
print(reversed_string5)

#other method to reverse using slicing with step
# Assignment / update: reversed_string6=combined_string[::-1]
reversed_string6=combined_string[::-1]  
# Action call: print(reversed_string6)
print(reversed_string6)

#other method to reverse using recursion with slicing
# Function 'reverse_string_recursion' definition
def reverse_string_recursion(s):
# Control block: if len(s) == 0:
    if len(s) == 0:
# Action call: return s
        return s
# Control block: else:
    else:
# Action call: return reverse_string_recursion(s[1:]) + s[0]
        return reverse_string_recursion(s[1:]) + s[0]
# Assignment / update: reversed_string7=reverse_string_recursion(combined_string)
reversed_string7=reverse_string_recursion(combined_string)
# Action call: print(reversed_string7)
print(reversed_string7)

#other method to reverse using stack with list comprehension
# Function 'reverse_string_stack_comprehension' definition
def reverse_string_stack_comprehension(s):
# Assignment / update: stack=[char for char in s]
    stack=[char for char in s]
# Assignment / update: reversed_string=""
    reversed_string=""
# Control block: while stack:
    while stack:
# Assignment / update: reversed_string+=stack.pop()
        reversed_string+=stack.pop()
# Action call: return reversed_string
    return reversed_string
# Assignment / update: reversed_string8=reverse_string_stack_comprehension(combined_string)
reversed_string8=reverse_string_stack_comprehension(combined_string)
# Action call: print(reversed_string8)
print(reversed_string8)

#other method to reverse using built-in function with slicing
# Assignment / update: reversed_string9="".join(reversed(combined_string))[::-1]
reversed_string9="".join(reversed(combined_string))[::-1]   
# Action call: print(reversed_string9)
print(reversed_string9)

#other method to reverse using slicing with step and built-in function
# Assignment / update: reversed_string10=combined_string[::-1][::-1]
reversed_string10=combined_string[::-1][::-1]
# Action call: print(reversed_string10)
print(reversed_string10)
