"""
Password Validation

This module provides a function to validate passwords based on common security requirements.
"""


def validate_password(password):
    """
    Validates a password for length and character requirements.

    Args:
        password (str): The password to validate.

    Returns:
        str: Validation result message.
    """
    if len(password) < 8:
        return "Password must be at least 8 characters long."
    has_upper = any(char.isupper() for char in password)
    has_lower = any(char.islower() for char in password)
    has_digit = any(char.isdigit() for char in password)
    has_special = any(not char.isalnum() for char in password)
    if not has_upper:
        return "Password must contain at least one uppercase letter."
    if not has_lower:
        return "Password must contain at least one lowercase letter."
    if not has_digit:
        return "Password must contain at least one digit."
    if not has_special:
        return "Password must contain at least one special character."
    return "Password is valid."
