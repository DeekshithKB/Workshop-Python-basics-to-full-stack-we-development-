"""
Tic-Tac-Toe Game

A simple command-line Tic-Tac-Toe game for two players.
"""


def print_board(board):
    """
    Prints the current state of the Tic-Tac-Toe board.

    Args:
        board (list of list): 3x3 grid representing the board.
    """
    for row in board:
        print(" | ".join(row))
        print("-" * 9)


def check_win(board, player):
    """
    Checks if the given player has won the game.

    Args:
        board (list of list): 3x3 grid representing the board.
        player (str): The player symbol ('X' or 'O').

    Returns:
        bool: True if the player has won, False otherwise.
    """
    # Check rows
    for row in board:
        if all(cell == player for cell in row):
            return True
    # Check columns
    for col in range(3):
        if all(board[row][col] == player for row in range(3)):
            return True
    # Check diagonals
    if all(board[i][i] == player for i in range(3)):
        return True
    if all(board[i][2 - i] == player for i in range(3)):
        return True
    return False


def check_draw(board):
    """
    Checks if the game is a draw (no empty cells left).

    Args:
        board (list of list): 3x3 grid representing the board.

    Returns:
        bool: True if it's a draw, False otherwise.
    """
    return all(cell != " " for row in board for cell in row)


def main():
    """
    Main function to run the Tic-Tac-Toe game.
    """
    board = [[" " for _ in range(3)] for _ in range(3)]
    current_player = "X"
    while True:
        print_board(board)
        row = int(input(f"Player {current_player}, enter row (0-2): "))
        col = int(input(f"Player {current_player}, enter column (0-2): "))
        if board[row][col] == " ":
            board[row][col] = current_player
            if check_win(board, current_player):
                print_board(board)
                print(f"Player {current_player} wins!")
                break
            elif check_draw(board):
                print_board(board)
                print("It's a draw!")
                break
            current_player = "O" if current_player == "X" else "X"
        else:
            print("Cell already occupied. Try again.")


if __name__ == "__main__":
    main()
