# file_comment_added: atm.py
# Purpose: Annotate and document the code blocks in atm.py.
# Note: comments inserted automatically for learning and review.

#ATM functionality for withdraw and deposit and check balance and transfer money to another account and change pin also check for sufficient balance for withdraw and transfer
# Class 'ATM' definition
class ATM:
# Function '__init__' definition
    def __init__(self, balance=0):
# Assignment / update: self.balance = balance
        self.balance = balance
# Function 'deposit' definition
    def deposit(self, amount):
# Assignment / update: self.balance += amount
        self.balance += amount
# Action call: return f"Deposited {amount}. Current balance: {self.balance}"
        return f"Deposited {amount}. Current balance: {self.balance}"
# Function 'withdraw' definition
    def withdraw(self, amount):
# Control block: if amount > self.balance:
        if amount > self.balance:
# Action call: return "Insufficient balance."
            return "Insufficient balance."
# Assignment / update: self.balance -= amount
        self.balance -= amount
# Action call: return f"Withdrew {amount}. Current balance: {self.balance}"
        return f"Withdrew {amount}. Current balance: {self.balance}"
# Function 'check_balance' definition
    def check_balance(self):
# Action call: return f"Current balance: {self.balance}"
        return f"Current balance: {self.balance}"
# Function 'transfer' definition
    def transfer(self, amount, recipient):
# Control block: if amount > self.balance:
        if amount > self.balance:
# Action call: return "Insufficient balance."
            return "Insufficient balance."
# Assignment / update: self.balance -= amount
        self.balance -= amount
# Assignment / update: recipient.balance += amount
        recipient.balance += amount
# Action call: return f"Transferred {amount} to recipient. Current balance: {self.balance}"
        return f"Transferred {amount} to recipient. Current balance: {self.balance}"
# Function 'change_pin' definition
    def change_pin(self, old_pin, new_pin):
        # This is a placeholder for pin change functionality
# Action call: return "Pin changed successfully."
        return "Pin changed successfully."
# Assignment / update: account1 = ATM(1000)
account1 = ATM(1000)
# Assignment / update: account2 = ATM(500)
account2 = ATM(500)
# Control block: while True:
while True:
# Assignment / update: abc=int(input("Enter \n 1 for deposit\n 2 for withdraw\n 3 for check balance\n 4 for transfer\n 5 for change pin:\n 6 for exit\n"))
    abc=int(input("Enter \n 1 for deposit\n 2 for withdraw\n 3 for check balance\n 4 for transfer\n 5 for change pin:\n 6 for exit\n")) 
# Control block: if abc == 1:
    if abc == 1:
# Action call: print(account1.deposit(int(input("Enter deposit amount: "))))
        print(account1.deposit(int(input("Enter deposit amount: "))))
# Control block: elif abc == 2:
    elif abc == 2:
# Action call: print(account1.withdraw(int(input("Enter withdrawal amount: "))))
        print(account1.withdraw(int(input("Enter withdrawal amount: "))))
# Control block: elif abc == 3:
    elif abc == 3:
# Action call: print(account1.check_balance())
        print(account1.check_balance())
# Control block: elif abc == 4:
    elif abc == 4:
# Assignment / update: recipient_id = input("Enter transaction id:")
        recipient_id = input("Enter transaction id:")
# Action call: print(account1.transfer(int(input("Enter transfer amount: ")), account2))
        print(account1.transfer(int(input("Enter transfer amount: ")), account2))
# Control block: elif abc == 5:
    elif abc == 5:
# Action call: print(account1.change_pin(input("Enter old pin: "), input("Enter new pin: ")))
        print(account1.change_pin(input("Enter old pin: "), input("Enter new pin: ")))
# Control block: elif abc == 6:
    elif abc == 6:
# Operation: break
        break
# Control block: else:
    else:
# Action call: print("Invalid option. Please try again.")
        print("Invalid option. Please try again.")
