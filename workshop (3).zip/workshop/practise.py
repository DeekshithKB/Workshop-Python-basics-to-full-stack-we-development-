# file_comment_added: practise.py
# Purpose: Annotate and document the code blocks in practise.py.
# Note: comments inserted automatically for learning and review.

# Assignment / update: a=10
a=10
# Action call: print(a)
print(a)
# Assignment / update: b=10
b=10
# Action call: print(b)
print(b)
# Action call: print(id(a))
print(id(a))
# Action call: print(id(b))
print(id(b))
# Assignment / update: a=20
a=20
# Action call: print(a)
print(a)
# Assignment / update: a=b
a=b
# Action call: print(a)
print(a)
# Assignment / update: b=a
b=a
# Action call: print(b)
print(b)
# Action call: print(id(a))
print(id(a))
# Action call: print(id(b))
print(id(b))
# Operation: """ valid variables:
""" valid variables: 
# Assignment / update: deekshith=10
deekshith=10
# Assignment / update: _apple=20
_apple=20
# Assignment / update: my_name="deekshith"
my_name="deekshith"

# Operation: invalid variables:
invalid variables:
# Assignment / update: 1name="deekshith"
1name="deekshith"
# Assignment / update: name$s="deekshith"
name$s="deekshith"
# Control block: while="deekshith" """
while="deekshith" """
