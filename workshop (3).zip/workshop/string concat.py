# file_comment_added: string concat.py
# Purpose: Annotate and document the code blocks in string concat.py.
# Note: comments inserted automatically for learning and review.

# Assignment / update: s="shalinee"
s="shalinee"
# Assignment / update: result='H'+s[1:]
result='H'+s[1:]
# Action call: print(result)
print(result)
# Assignment / update: result1=s[:2]+'b'+s[3:]
result1=s[:2]+'b'+s[3:]
# Action call: print(result1)
print(result1)
