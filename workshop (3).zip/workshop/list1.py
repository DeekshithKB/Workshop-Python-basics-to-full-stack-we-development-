# file_comment_added: list1.py
# Purpose: Annotate and document the code blocks in list1.py.
# Note: comments inserted automatically for learning and review.

# Assignment / update: numbers=[5,2,9,1,7]
numbers=[5,2,9,1,7]
# Operation: numbers.sort()
numbers.sort()
# Action call: print("sorted in ascending order:", numbers)
print("sorted in ascending order:", numbers)
# Assignment / update: numbers.sort(reverse=True)
numbers.sort(reverse=True)
# Action call: print("sorted in descending order:", numbers)
print("sorted in descending order:", numbers)
# Operation: numbers.append(10)
numbers.append(10)
# Action call: print("appended:", numbers)
print("appended:", numbers)

# Assignment / update: new_list = sorted(numbers)
new_list = sorted(numbers)
# Action call: print("new list (sorted):", new_list)
print("new list (sorted):", new_list)
# Assignment / update: abcd=[4,7,53,2,9]
abcd=[4,7,53,2,9]
#reverse and reverse() are different
# Operation: abcd.reverse()
abcd.reverse()
# Action call: print("reversed:", abcd)
print("reversed:", abcd)

# Assignment / update: deg=[0,90,180,270]
deg=[0,90,180,270]
#reversed() returns an iterator that can be converted to a list
# Assignment / update: reversed_deg = list(reversed(deg))
reversed_deg = list(reversed(deg))
# Action call: print("reversed degrees:", reversed_deg)
print("reversed degrees:", reversed_deg)
# Operation: numbers.append(15)
numbers.append(15)
# Operation: numbers.append(20)
numbers.append(20)
# Action call: print("appended 15 and 20:", numbers)
print("appended 15 and 20:", numbers)
# Operation: numbers.insert(0, 12)
numbers.insert(0, 12)
# Action call: print("inserted 12 at index 0:", numbers)
print("inserted 12 at index 0:", numbers)
# Operation: numbers.insert(2, 12)
numbers.insert(2, 12)
# Action call: print("inserted 12 at index 2:", numbers)
print("inserted 12 at index 2:", numbers)
# Operation: numbers.remove(9)
numbers.remove(9)
# Action call: print("removed 9:", numbers)
print("removed 9:", numbers)
# Assignment / update: popped_number = numbers.pop(3)
popped_number = numbers.pop(3)
# Action call: print("popped number at index 3:", popped_number)
print("popped number at index 3:", popped_number)
# Action call: print("numbers after popping:", numbers)
print("numbers after popping:", numbers)
# Assignment / update: squared = [x**2 for x in numbers]
squared = [x**2 for x in numbers]
# Action call: print("squared numbers:", squared)
print("squared numbers:", squared)
# Assignment / update: nested_list = [[1, 2], [3, 4], [5, 6]]
nested_list = [[1, 2], [3, 4], [5, 6]]
# Action call: print("nested list:", nested_list)
print("nested list:", nested_list)
# Action call: print("first sublist:", nested_list[0])
print("first sublist:", nested_list[0])
# Action call: print("first element of second sublist:", nested_list[1][0])
print("first element of second sublist:", nested_list[1][0])
# Action call: print("second element of third sublist:", nested_list[2][1])
print("second element of third sublist:", nested_list[2][1])
# Operation: numbers.append([25, 30])
numbers.append([25, 30])
# Action call: print("appended nested list:", numbers)
print("appended nested list:", numbers)
