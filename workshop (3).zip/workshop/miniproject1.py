# Multiple Student Record Manager using Dictionary and File Handling
RECORD_FILE = "student_records.txt"
def load_records():
    records = {}
    try:
        with open(RECORD_FILE, "r") as f:
            for line in f:
                line = line.strip()
                if not line:
                    continue
                parts = line.split(":")
                if len(parts) == 2:
                    name = parts[0].strip()
                    marks_str = parts[1].strip()
                    if marks_str:
                        marks = [float(m.strip()) for m in marks_str.split(",") if m.strip()]
                        records[name] = marks
                    else:
                        records[name] = []
    except FileNotFoundError:
        pass  # No file, start empty
    except (ValueError, IOError) as e:
        print(f"Error loading records: {e}. Starting with empty records.")
    return records
def save_records(records):
    try:
        with open(RECORD_FILE, "w") as f:
            for name, marks in records.items():
                marks_str = ",".join(str(m) for m in marks)
                f.write(f"{name}:{marks_str}\n")
        print("Records saved successfully.")
    except IOError as e:
        print(f"Error saving records: {e}")
def add_student(records):
    while True:
        name = input("Enter student name: ").strip()
        if not name:
            print("Name cannot be empty.")
            continue
        if name in records:
            print("Student already exists. Use update to modify.")
            continue
        break
    while True:
        try:
            count = int(input("Enter the number of subjects: "))
            if count <= 0:
                print("Count must be positive.")
                continue
            break
        except ValueError:
            print("Invalid input. Please enter a number.")
    marks = []
    for i in range(count):
        while True:
            try:
                mark = float(input(f"Enter mark for subject {i+1}: "))
                marks.append(mark)
                break
            except ValueError:
                print("Invalid mark. Please enter a number.")
    records[name] = marks
    print(f"Added student {name} with marks {marks}.")
def update_student(records):
    if not records:
        print("No records to update.")
        return
    display_records(records)
    while True:
        name = input("Enter student name to update: ").strip()
        if name not in records:
            print("Student not found.")
            continue
        break
    print(f"Current marks for {name}: {records[name]}")
    while True:
        try:
            count = int(input("Enter new count of marks: "))
            if count <= 0:
                print("Count must be positive.")
                continue
            break
        except ValueError:
            print("Invalid input. Please enter a number.")
    marks = []
    for i in range(count):
        while True:
            try:
                mark = float(input(f"Enter new mark for subject {i+1}: "))
                marks.append(mark)
                break
            except ValueError:
                print("Invalid mark. Please enter a number.")
    records[name] = marks
    print(f"Updated student {name} with marks {marks}.")
def display_records(records):
    if not records:
        print("No records to display.")
        return
    print("\nStudent Records:")
    for name, marks in records.items():
        if marks:
            avg = sum(marks) / len(marks)
            print(f"Name: {name}, Marks: {marks}, Average: {avg:.2f}")
        else:
            print(f"Name: {name}, Marks: {marks}")
def main():
    records = load_records()
    while True:
        print("\nOptions:")
        print("1. Add Student")
        print("2. Update Student")
        print("3. Display Records")
        print("4. Save Records")
        print("5. Exit")
        choice = input("Choose an option: ").strip()
        if choice == "1":
            add_student(records)
        elif choice == "2":
            update_student(records)
        elif choice == "3":
            display_records(records)
        elif choice == "4":
            save_records(records)
        elif choice == "5":
            save_records(records)
            print("Exiting...")
            break
        else:
            print("Invalid choice.")

main()