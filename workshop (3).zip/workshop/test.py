"""
OOP Concepts Demonstration

This module demonstrates basic Object-Oriented Programming concepts in Python:
- Classes and objects
- Inheritance
- Polymorphism
- Encapsulation
"""

# Classes and objects
class Car:
    """Represents a car with brand and price."""

    def __init__(self, brand, price):
        """Initializes the car with brand and price."""
        self.brand = brand
        self.price = price

    def display(self):
        """Displays the car's brand and price."""
        print("Brand:", self.brand)
        print("Price:", self.price)


car1 = Car("Toyota", 20000)
car1.display()
car2 = Car("Honda", 25000)
car2.display()

# Inheritance
class ElectricCar(Car):
    """Represents an electric car inheriting from Car."""

    def __init__(self, brand, price, battery_capacity):
        """Initializes the electric car with brand, price, and battery capacity."""
        super().__init__(brand, price)
        self.battery_capacity = battery_capacity

    def display(self):
        """Displays the electric car's details including battery capacity."""
        super().display()
        print("Battery Capacity:", self.battery_capacity)


electric_car1 = ElectricCar("Tesla", 50000, 100)
electric_car1.display()
electric_car2 = ElectricCar("Nissan", 30000, 80)
electric_car2.display()

# Polymorphism
class Shape:
    """Abstract base class for shapes."""

    def area(self):
        """Calculates the area of the shape. To be overridden by subclasses."""
        pass


class Circle(Shape):
    """Represents a circle."""

    def __init__(self, radius):
        """Initializes the circle with radius."""
        self.radius = radius

    def area(self):
        """Calculates the area of the circle."""
        return 3.14 * self.radius * self.radius


class Rectangle(Shape):
    """Represents a rectangle."""

    def __init__(self, length, width):
        """Initializes the rectangle with length and width."""
        self.length = length
        self.width = width

    def area(self):
        """Calculates the area of the rectangle."""
        return self.length * self.width


circle = Circle(5)
print("Area of Circle:", circle.area())
rectangle = Rectangle(4, 6)
print("Area of Rectangle:", rectangle.area())

# Encapsulation
class BankAccount:
    """Represents a bank account with encapsulation."""

    def __init__(self, account_number, balance):
        """Initializes the bank account with account number and balance."""
        self.__account_number = account_number
        self.__balance = balance

    def deposit(self, amount):
        """Deposits the specified amount into the account."""
        self.__balance += amount
        print("Amount deposited. Current balance:", self.__balance)

    def withdraw(self, amount):
        """Withdraws the specified amount from the account if sufficient balance."""
        if amount > self.__balance:
            print("Insufficient balance.")
        else:
            self.__balance -= amount
            print("Amount withdrawn. Current balance:", self.__balance)


account = BankAccount("123456789", 1000)
account.deposit(500)
account.withdraw(200)
account.withdraw(1500)
