# file_comment_added: question4.py
# Purpose: Annotate and document the code blocks in question4.py.
# Note: comments inserted automatically for learning and review.

#find the largest and smallest among 3 numbers
# Assignment / update: num1=int(input("Enter 1st number:"))
num1=int(input("Enter 1st number:"))
# Assignment / update: num2=int(input("Enter 2nd number:"))
num2=int(input("Enter 2nd number:"))
# Assignment / update: num3=int(input("enter 3rd number:"))
num3=int(input("enter 3rd number:"))
# Control block: if num1 > num2 and num1 > num3:
if num1 > num2 and num1 > num3:
# Action call: print("Largest is:", num1)
    print("Largest is:", num1)
# Control block: elif num2 > num1 and num2 > num3:
elif num2 > num1 and num2 > num3:
# Action call: print("Largest is:", num2)
    print("Largest is:", num2)
# Control block: elif num1 == num2 and num1 > num3:
elif num1 == num2 and num1 > num3:
# Action call: print("largest is ",num1,"and both num1 and num2 are equal")
    print("largest is ",num1,"and both num1 and num2 are equal")
# Control block: elif num1 == num3 and num1>num2:
elif num1 == num3 and num1>num2:
# Action call: print("largest is ",num1,"and both num1 and num3 are equal")
    print("largest is ",num1,"and both num1 and num3 are equal")
# Control block: elif num2 == num3 and num2>num1:
elif num2 == num3 and num2>num1:
# Action call: print("largest is ",num2,"and both num2 and num3 are equal")
    print("largest is ",num2,"and both num2 and num3 are equal")
# Control block: else:
else:
# Action call: print("Largest is:", num3)
    print("Largest is:", num3)
