"""
Functions with Different Parameters

This module demonstrates various types of functions in Python:
- Functions without parameters
- Functions with parameters
- Functions with default parameters
- Functions with return values
"""


def without_parameters():
    """Prints a message for a function with no parameters."""
    print("This function has no parameters.")


without_parameters()


def with_parameters(name, age):
    """
    Prints name and age.

    Args:
        name (str): The name.
        age (int): The age.
    """
    print(f"My name is {name} and I am {age} years old.")


a = input("Enter your name: ")
b = int(input("Enter your age: "))
with_parameters(a, b)


def with_default_parameters(name="Deekshith", age=20):
    """
    Prints name and age with default values.

    Args:
        name (str): The name (default "Deekshith").
        age (int): The age (default 20).
    """
    print(f"My name is {name} and I am {age} years old.")


with_default_parameters()
with_default_parameters("Antony", 25)
with_default_parameters(age=40)
with_default_parameters(name="prakyath")


def with_return_value(num1, num2):
    """
    Returns the sum of two numbers.

    Args:
        num1 (int or float): First number.
        num2 (int or float): Second number.

    Returns:
        int or float: The sum.
    """
    return num1 + num2


result = with_return_value(5, 10)
print(f"The sum of 5 and 10 is {result}.")


def name(name):
    """
    Returns a greeting message.

    Args:
        name (str): The name.

    Returns:
        str: Greeting message.
    """
    return f"Hello, {name}!"


print(name(input("Enter your name: ")))


def addition(a, b):
    """
    Returns the sum of two numbers.

    Args:
        a (int or float): First number.
        b (int or float): Second number.

    Returns:
        int or float: The sum.
    """
    return a + b


num1 = int(input("Enter first number: "))
num2 = int(input("Enter second number: "))
result = addition(num1, num2)
print(f"The sum of {num1} and {num2} is {result}.")


def even_odd(num):
    """
    Checks if a number is even or odd.

    Args:
        num (int): The number.

    Returns:
        str: "Even" or "Odd".
    """
    if num % 2 == 0:
        return "Even"
    else:
        return "Odd"


number = int(input("Enter a number: "))
result = even_odd(number)
print(f"The number {number} is {result}.")


def greet(name):
    """
    Returns a greeting message.

    Args:
        name (str): The name.

    Returns:
        str: Greeting message.
    """
    return f"Hello, {name}!"


print(greet(name=input("Enter your name: ")))
