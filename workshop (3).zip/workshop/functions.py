"""
Functions Demonstration

This module demonstrates various Python functions including greeting, even/odd check,
prime number check, addition, palindrome check, finding largest number, and more.
"""


def greet(name):
    """
    Returns a greeting message for the given name.

    Args:
        name (str): The name to greet.

    Returns:
        str: The greeting message.
    """
    return f"Hello, {name}!"


print(greet(name=input("Enter your name: ")))


def check_even_odd(num):
    """
    Checks if a number is even or odd.

    Args:
        num (int): The number to check.

    Returns:
        str: "Even" if even, "Odd" if odd.
    """
    if num % 2 == 0:
        return "Even"
    else:
        return "Odd"


number = int(input("Enter a number: "))
result = check_even_odd(number)
print(f"The number {number} is {result}.")


def is_prime(num):
    """
    Checks if a number is prime.

    Args:
        num (int): The number to check.

    Returns:
        bool: True if prime, False otherwise.
    """
    if num <= 1:
        return False
    for i in range(2, int(num**0.5) + 1):
        if num % i == 0:
            return False
    return True


number = int(input("Enter a number: "))
result = is_prime(number)
print(f"The number {number} is {'prime' if result else 'not prime'}.")


def add_numbers(a, b):
    """
    Adds two numbers.

    Args:
        a (int or float): First number.
        b (int or float): Second number.

    Returns:
        int or float: The sum.
    """
    return a + b


num1 = int(input("Enter first number: "))
num2 = int(input("Enter second number: "))
result = add_numbers(num1, num2)
print(f"The sum of {num1} and {num2} is {result}.")


def is_palindrome(s):
    """
    Checks if a string is a palindrome and returns the reversed string.

    Args:
        s (str): The string to check.

    Returns:
        str: The reversed string.
    """
    s = s.replace(" ", "").lower()
    return s[::-1]


string = input("Enter a string: ")
result = is_palindrome(string)
if string == result:
    print(f"{string} is a palindrome.")
else:
    print(f"{string} is not a palindrome.")
print("Reversed string is:", result)


def find_largest(a, b, c, d, e):
    """
    Finds the largest of five numbers.

    Args:
        a, b, c, d, e: The numbers to compare.

    Returns:
        The largest number.
    """
    return max(a, b, c, d, e)


num1 = int(input("Enter first number: "))
num2 = int(input("Enter second number: "))
num3 = int(input("Enter third number: "))
num4 = int(input("Enter fourth number: "))
num5 = int(input("Enter fifth number: "))
largest = find_largest(num1, num2, num3, num4, num5)
print(f"The largest number is {largest}.")


def greatest(a, b):
    """
    Returns the greater of two numbers.

    Args:
        a, b: The numbers to compare.

    Returns:
        The greater number.
    """
    return max(a, b)


def square(num1, num2):
    """
    Returns the squares of two numbers.

    Args:
        num1, num2: The numbers to square.

    Returns:
        tuple: Squares of num1 and num2.
    """
    return num1 ** 2, num2 ** 2


def arithmetic_operations(a, b):
    """
    Performs an arithmetic operation on two numbers based on user input.

    Args:
        a, b: The numbers.

    Returns:
        The result of the operation.
    """
    op = input("Any arithmetic operation you want to perform (+,-,/,*): ")
    if op == "+":
        return a + b
    elif op == "-":
        return a - b
    elif op == "/":
        return a / b
    elif op == "*":
        return a * b
    else:
        print("Undefined operation")
        return None


a = int(input("Enter a number: "))
b = int(input("Enter another number: "))
gre = greatest(a, b)
print("Greatest number:", gre)
squ = square(a, b)
print(f"The square of {a} and {b} is {squ}")
ari = arithmetic_operations(a, b)
print("Answer:", ari)

# Example tuple
example = ("hello", 1, 2, 3.5, True)
print(example)



