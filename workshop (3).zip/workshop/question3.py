# file_comment_added: question3.py
# Purpose: Annotate and document the code blocks in question3.py.
# Note: comments inserted automatically for learning and review.

#check even or odd
# Assignment / update: num = int(input("Enter a number: "))
num = int(input("Enter a number: "))
# Control block: if num % 2==0:
if num % 2==0:
# Action call: print(num, "even number.")
    print(num, "even number.")
# Control block: else:
else:
# Action call: print(num, "odd number.")
    print(num, "odd number.")

#find the largest of two numbers
# Assignment / update: num1 = int(input("Enter first number: "))
num1 = int(input("Enter first number: "))
# Assignment / update: num2 = int(input("Enter second number: "))
num2 = int(input("Enter second number: "))
# Control block: if num1 > num2:
if num1 > num2:
# Action call: print(num1,"is the largest number.")
    print(num1,"is the largest number.")
# Control block: else:
else:
# Action call: print(num2,"is the largest number.")
    print(num2,"is the largest number.")

#convert string "50" to integer and add 10
# Assignment / update: s = "50"
s = "50"
# Assignment / update: num = int(s)
num = int(s)
# Assignment / update: result = num + 10
result = num + 10
# Action call: print("Result:", result)
print("Result:", result)

#Create a simple calculator
# Assignment / update: num1 = int(input("Enter first number: "))
num1 = int(input("Enter first number: "))
# Assignment / update: num2 = int(input("Enter second number: "))
num2 = int(input("Enter second number: "))
# Assignment / update: opern = input("Enter operation (+, -, *, /,**(for power)): ")
opern = input("Enter operation (+, -, *, /,**(for power)): ")
# Control block: if opern == "+":
if opern == "+":
# Assignment / update: result = num1+num2
    result = num1+num2
# Action call: print("Result:",result)
    print("Result:",result)
# Control block: elif opern == "-":
elif opern == "-":
# Assignment / update: result = num1-num2
    result = num1-num2
# Action call: print("Result:",result)
    print("Result:",result)
# Control block: elif opern == "*":
elif opern == "*":
# Assignment / update: result = num1*num2
    result = num1*num2
# Action call: print("Result:",result)
    print("Result:",result)
# Control block: elif opern == "**":
elif opern == "**":
# Assignment / update: result = num1**num2
    result = num1**num2
# Action call: print("Result:",result)
    print("Result:",result)
# Control block: elif opern=="/":
elif opern=="/":
# Control block: if num2!= 0:
    if num2!= 0:
# Assignment / update: result = num1/num2
        result = num1/num2
# Action call: print("Result:",result)
        print("Result:",result)
# Control block: else:
    else:
# Action call: print("Error: Zero division error.")
        print("Error: Zero division error.")
# Control block: else:
else:
# Action call: print("Invalid operation. use +, -, *, /.")
    print("Invalid operation. use +, -, *, /.")

#create a password from user and then a message then ask them to enter the password and if it matches the original password then print the message
# Assignment / update: password = input("Create a password: ")
password = input("Create a password: ") 
# Assignment / update: message = input("Enter a message: ")
message = input("Enter a message: ")
# Action call: print("*\n"*50)
print("*\n"*50)
# Assignment / update: entered_password = input("Enter the password to see the message: ")
entered_password = input("Enter the password to see the message: ")
# Control block: if entered_password == password:
if entered_password == password:
# Action call: print("Message:", message)
    print("Message:", message)
# Control block: else:
else:
# Action call: print("Incorrect password. Access denied.")
    print("Incorrect password. Access denied.")
