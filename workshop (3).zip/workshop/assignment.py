"""
User Input and Basic Operations

This module demonstrates taking user input and performing basic operations like printing and summing.
"""

name = input("Enter your name: ")
age = int(input("Enter your age: "))
city = input("Enter your city: ")
print("Name:", name)
print("Age:", age)
print("City:", city)

salary = int(input("Enter your salary: "))
print("The salary is:", salary)
print(type(salary))

a = int(input("Enter a number: "))
b = int(input("Enter another number: "))
sum = a + b
print("The sum of", a, "and", b, "is", sum)
