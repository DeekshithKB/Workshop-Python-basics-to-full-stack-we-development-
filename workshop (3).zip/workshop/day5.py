# file_comment_added: day5.py
# Purpose: Annotate and document the code blocks in day5.py.
# Note: comments inserted automatically for learning and review.

#taking input from user
# Assignment / update: name=input("Enter your name: ")
name=input("Enter your name: ")
# Action call: print(type(name))
print(type(name))
# Action call: print("Welcome",name)
print("Welcome",name)

#take age as input and print it
# Assignment / update: age=int(input("Enter your age: "))
age=int(input("Enter your age: "))
# Action call: print("Your age is:", age)
print("Your age is:", age)
# Action call: print(type(age))
print(type(age))

#take 2 numbers as input and print their sum
# Assignment / update: a=float(input("Enter a number: "))
a=float(input("Enter a number: "))
# Assignment / update: b=float(input("Enter another number: "))
b=float(input("Enter another number: "))
# Assignment / update: sum=a+b
sum=a+b
# Action call: print("The sum of", a, "and", b, "is", sum)
print("The sum of", a, "and", b, "is", sum)
# Action call: print(type(sum))
print(type(sum))

#take any input and print it along with its type
# Assignment / update: abc=input("Enter anything: ")
abc=input("Enter anything: ")
# Action call: print("You entered:", abc)
print("You entered:", abc)
# Action call: print(type(abc))
print(type(abc))

#address of input variable
# Action call: print("Address of name variable:", id(name))
print("Address of name variable:", id(name))
# Action call: print("Address of age variable:", id(age))
print("Address of age variable:", id(age))
# Action call: print("Address of a variable:", id(a))
print("Address of a variable:", id(a))
# Action call: print("Address of b variable:", id(b))
print("Address of b variable:", id(b))
# Action call: print("Address of sum variable:", id(sum))
print("Address of sum variable:", id(sum))  
# Action call: print("Address of abc variable:", id(abc))
print("Address of abc variable:", id(abc))
