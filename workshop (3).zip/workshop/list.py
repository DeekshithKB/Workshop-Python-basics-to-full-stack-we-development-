# file_comment_added: list.py
# Purpose: Annotate and document the code blocks in list.py.
# Note: comments inserted automatically for learning and review.

# Assignment / update: my_list = [1, 2, 3, 4, 5]
my_list = [1, 2, 3, 4, 5]
# Accessing elements
# Action call: print(my_list[0])  # Output: 1
print(my_list[0])  # Output: 1
# Action call: print(my_list[2])  # Output: 3
print(my_list[2])  # Output: 3
# Modifying elements
# Assignment / update: my_list[1] = 20
my_list[1] = 20
# Action call: print(my_list)  # Output: [1, 20, 3, 4, 5]
print(my_list)  # Output: [1, 20, 3, 4, 5]
# Adding elements
# Operation: my_list.append(6)
my_list.append(6)
# Action call: print(my_list)  # Output: [1, 20, 3, 4, 5, 6]
print(my_list)  # Output: [1, 20, 3, 4, 5, 6]
# Operation: my_list.insert(2, 15)
my_list.insert(2, 15)
# Action call: print(my_list)  # Output: [1, 20, 15, 3, 4, 5, 6]
print(my_list)  # Output: [1, 20, 15, 3, 4, 5, 6]
# Removing elements
# Operation: my_list.remove(20)
my_list.remove(20)
# Action call: print(my_list)  # Output: [1, 15, 3, 4, 5, 6]
print(my_list)  # Output: [1, 15, 3, 4, 5, 6]
# Operation: my_list.pop(2)
my_list.pop(2)  
# Action call: print(my_list)  # Output: [1, 15, 4, 5, 6]
print(my_list)  # Output: [1, 15, 4, 5, 6]
# Slicing
# Action call: print(my_list[1:4])  # Output: [15, 4, 5]
print(my_list[1:4])  # Output: [15, 4, 5]
# Action call: print(my_list[:3])   # Output: [1, 15, 4]
print(my_list[:3])   # Output: [1, 15, 4]
# Action call: print(my_list[3:])   # Output: [5, 6]
print(my_list[3:])   # Output: [5, 6]
# Length of the list
# Action call: print(len(my_list))  # Output: 5
print(len(my_list))  # Output: 5
# Iterating through the list
# Control block: for item in my_list:
for item in my_list:
# Action call: print(item)
    print(item)

# List comprehension
# Assignment / update: squared = [x**2 for x in my_list]
squared = [x**2 for x in my_list]
# Action call: print(squared)  # Output: [1, 225, 16, 25, 36]
print(squared)  # Output: [1, 225, 16, 25, 36]

# Nested lists
# Assignment / update: nested_list = [[1, 2], [3, 4], [5, 6]]
nested_list = [[1, 2], [3, 4], [5, 6]]
# Action call: print(nested_list[0])  # Output: [1, 2]
print(nested_list[0])  # Output: [1, 2]
# Action call: print(nested_list[1][0])  # Output: 3
print(nested_list[1][0])  # Output: 3
# Action call: print(nested_list[2][1])  # Output: 6
print(nested_list[2][1])  # Output: 6

# Sorting a list
# Assignment / update: numbers = [5, 2, 9, 1, 7]
numbers = [5, 2, 9, 1, 7]
# Operation: numbers.sort()
numbers.sort()
# Action call: print(numbers)  # Output: [1, 2, 5, 7, 9]
print(numbers)  # Output: [1, 2, 5, 7, 9]
# Assignment / update: numbers.sort(reverse=True)
numbers.sort(reverse=True)
# Action call: print(numbers)
print(numbers)
# Output: [9, 7, 5, 2, 1]

# List methods
# Operation: my_list.append(10)
my_list.append(10)
# Action call: print(my_list)  # Output: [1, 15, 4, 5, 6, 10]
print(my_list)  # Output: [1, 15, 4, 5, 6, 10]
# Operation: my_list.extend([11, 12])
my_list.extend([11, 12])
# Action call: print(my_list)  # Output: [1, 15, 4, 5, 6, 10, 11, 12]
print(my_list)  # Output: [1, 15, 4, 5, 6, 10, 11, 12]
# Operation: my_list.remove(4)
my_list.remove(4)
# Action call: print(my_list)  # Output: [1, 15, 5, 6, 10, 11, 12]
print(my_list)  # Output: [1, 15, 5, 6, 10, 11, 12]
# Operation: my_list.pop()
my_list.pop()
# Action call: print(my_list)  # Output: [1, 15, 5, 6, 10, 11]
print(my_list)  # Output: [1, 15, 5, 6, 10, 11]
# Operation: my_list.clear()
my_list.clear()
# Action call: print(my_list)  # Output: []
print(my_list)  # Output: []
# Operation: my_list.append(1)
my_list.append(1)
# Operation: my_list.append(2)
my_list.append(2)
# Operation: my_list.append(3)
my_list.append(3)
# Action call: print(my_list)  # Output: [1, 2, 3]
print(my_list)  # Output: [1, 2, 3]

# Copying a list
# Assignment / update: copied_list = my_list.copy()
copied_list = my_list.copy()
# Action call: print(copied_list)  # Output: [1, 2, 3]
print(copied_list)  # Output: [1, 2, 3]

# List concatenation
# Assignment / update: list1 = [1, 2, 3]
list1 = [1, 2, 3]
# Assignment / update: list2 = [4, 5, 6]
list2 = [4, 5, 6]
# Assignment / update: concatenated_list = list1 + list2
concatenated_list = list1 + list2
# Action call: print(concatenated_list)  # Output: [1, 2, 3, 4, 5, 6]
print(concatenated_list)  # Output: [1, 2, 3, 4, 5, 6]

# List repetition
# Assignment / update: repeated_list = list1 * 3
repeated_list = list1 * 3
# Action call: print(repeated_list)  # Output: [1, 2, 3, 1, 2, 3, 1, 2, 3]
print(repeated_list)  # Output: [1, 2, 3, 1, 2, 3, 1, 2, 3]

# Checking for membership
# Action call: print(2 in list1)  # Output: True
print(2 in list1)  # Output: True
# Action call: print(5 in list1)  # Output: False
print(5 in list1)  # Output: False

# List slicing with step
# Action call: print(list1[::2])  # Output: [1, 3]
print(list1[::2])  # Output: [1, 3]

#adding more elements in between of the list
# Operation: list1.insert(2, 15)
list1.insert(2, 15)
# Action call: print(list1)  # Output: [1, 2, 15, 3]
print(list1)  # Output: [1, 2, 15, 3]
# Operation: list1.insert(0, 0)
list1.insert(0, 0)
# Action call: print(list1)  # Output: [0, 1, 2, 15, 3]
print(list1)  # Output: [0, 1, 2, 15, 3]

#count
# Action call: print(list1.count(15))  # Output: 1
print(list1.count(15))  # Output: 1
# Action call: print(list1.count(2))   # Output: 1
print(list1.count(2))   # Output: 1
# Action call: print(list1.count(0))   # Output: 1
print(list1.count(0))   # Output: 1
# Operation: list1.extend([15, 15, 2])
list1.extend([15, 15, 2])
# Action call: print(list1)  # Output: [0, 1, 2, 15, 3, 15, 15, 2]
print(list1)  # Output: [0, 1, 2, 15, 3, 15, 15, 2]
# Action call: print(list1.count(15))  # Output: 3
print(list1.count(15))  # Output: 3
# Action call: print(list1.count(2))   # Output: 2
print(list1.count(2))   # Output: 2
