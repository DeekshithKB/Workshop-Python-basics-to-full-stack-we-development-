#zero division error by taking input from user
def zero_division():
    try:
        num1 = int(input("Enter a number: "))
        num2 = int(input("Enter another number: "))
        result = num1 / num2
        print(f"The result of {num1} divided by {num2} is {result}.")
    except ZeroDivisionError:
        print("Error: You cannot divide by zero.")

zero_division()

def value_error():
    try:
        num = int(input("Enter a number: "))
        print(f"You entered: {num}")
    except ValueError:
        print("Error: Invalid input. Please enter a valid integer.")
value_error()

#index error by accessing an index that is out of range
def index_error():
    try:
        my_list = [1, 2, 3]
        print(my_list[5])
    except IndexError:
        print("Error: Index out of range. Please access a valid index.")
index_error()

#key error by accessing a key that does not exist in a dictionary
def key_error():
    try:
        my_dict = {"name": "Alice", "age": 30}
        print(my_dict["address"])
    except KeyError:
        print("Error: Key not found in the dictionary. Please access a valid key.")
key_error()

#type error by performing an operation on incompatible types
def type_error():   
    try:
        num = 10
        text = "Hello"
        result = num + text
        print(result)
    except TypeError:
        print("Error: Incompatible types. Please perform operations on compatible types.")
type_error()


#file not found error by trying to open a file that does not exist
def file_not_found_error():
    try:
        with open("non_existent_file.txt", "r") as file:
            content = file.read()
            print(content)
    except FileNotFoundError:
        print("Error: File not found. Please check the file name and try again.")
file_not_found_error()

#importing a module that does not exist
def module_not_found_error():
    try:
        import non_existent_module
    except ModuleNotFoundError:
        print("Error: Module not found. Please check the module name and try again.")
module_not_found_error()

def attribute_error():
    try:
        my_list = [1, 2, 3]
        my_list.append(4)
        print(my_list)
        my_list.non_existent_method()
    except AttributeError:
        print("Error: Attribute not found. Please check the method name and try again.")
attribute_error()

def name_error():
    try:
        print(undefined_variable)
    except NameError:
        print("Error: Name not defined. Please check the variable name and try again.")
name_error()

def import_error():
    try:
        from non_existent_module import non_existent_function
    except ImportError:
        print("Error: Import failed. Please check the module and function names and try again.")
import_error()

def syntax_error():
    try:
        eval("print('Hello World'")
    except SyntaxError:
        print("Error: Syntax error. Please check the code syntax and try again.")
syntax_error()

def indentation_error():
    try:
        exec("""def my_function():  
print("Hello World!")""")
    except IndentationError:
        print("Error: Indentation error. Please check the code indentation and try again.")
indentation_error()

def overflow_error():
    try:
        import math
        result = math.exp(1000)
        print(result)
    except OverflowError:
        print("Error: Overflow error. The result is too large to handle.")
overflow_error()

def memory_error():
    try:
        large_list = [0] * (10**10)
    except MemoryError:
        print("Error: Memory error. The operation requires too much memory.")
memory_error()

def recursion_error():
    try:
        def recursive_function():
            return recursive_function()
        recursive_function()
    except RecursionError:
        print("Error: Recursion error. Maximum recursion depth exceeded.")
recursion_error()

def exception_handling():
    try:
        num1 = int(input("Enter a number: "))
        num2 = int(input("Enter another number: "))
        result = num1 / num2
        print(f"The result of {num1} divided by {num2} is {result}.")
    except ZeroDivisionError:
        print("Error: You cannot divide by zero.")
    except ValueError:
        print("Error: Invalid input. Please enter a valid integer.")
    except Exception as e:
        print(f"An unexpected error occurred: {e}")
exception_handling()

def finally_block():
    try:
        num1 = int(input("Enter a number: "))
        num2 = int(input("Enter another number: "))
        result = num1 / num2
        print(f"The result of {num1} divided by {num2} is {result}.")
    except ZeroDivisionError:
        print("Error: You cannot divide by zero.")
    except ValueError:
        print("Error: Invalid input. Please enter a valid integer.")
    finally:
        print("This block will always execute, regardless of exceptions.")
finally_block()

def else_block():
    try:
        num1 = int(input("Enter a number: "))
        num2 = int(input("Enter another number: "))
        result = num1 / num2
    except ZeroDivisionError:
        print("Error: You cannot divide by zero.")
    except ValueError:
        print("Error: Invalid input. Please enter a valid integer.")
    else:
        print(f"The result of {num1} divided by {num2} is {result}.")
else_block()

    #nested try block
def nested_try():
        try:
            try:
                num = int(input("Enter a number: "))
                result = 10 / num
                print(f"The result of 10 divided by {num} is {result}.")
            except ZeroDivisionError:
                print("Error: You cannot divide by zero.")
        except ValueError:
            print("Error: Invalid input. Please enter a valid integer.")
nested_try()

#logical error handling
def logical_error():
    try:
        num1 = int(input("Enter a number: "))
        num2 = int(input("Enter another number: "))
        if num1 > num2:
            print(f"{num1} is greater than {num2}.")
        elif num1 < num2:
            print(f"{num2} is greater than {num1}.")
        else:
            print("Both numbers are equal.")
    except ValueError:
        print("Error: Invalid input. Please enter a valid integer.")
logical_error()
