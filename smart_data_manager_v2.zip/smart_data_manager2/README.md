# Smart Data Manager v2
### ATOM Workshop · 6th Semester Post Assessment

---

## 🚀 Quick Start

```bash
pip install flask
python app.py
# Open: http://127.0.0.1:5000
```

---

## 🔐 Teacher Password
Default: `atom2024`
To change: edit `TEACHER_PASSWORD` in `app.py` line 10.

---

## 📁 Structure

```
smart_data_manager/
├── app.py                     ← Flask backend
├── requirements.txt
├── tasks.json                 ← Auto-created data file
├── templates/
│   ├── base.html              ← Shared layout
│   ├── landing.html           ← Home (choose Student or Teacher)
│   ├── student.html           ← Student form (13 fields)
│   ├── student_success.html   ← Submission confirmation
│   ├── teacher_login.html     ← Password-protected login
│   ├── teacher_dashboard.html ← Full data view + filter/search
│   └── teacher_update.html    ← Edit status/priority/notes
└── static/
    ├── style.css
    └── script.js
```

---

## ✅ Assessment Coverage

| Requirement | Implementation |
|---|---|
| HTML Form | 13-field student form across 4 sections |
| JS Validation | Blocks submit, highlights errors, clears on fix |
| Flask `/` | Landing page |
| Flask `/add` → `/student/submit` | POST route saves to JSON |
| Flask `/view` → `/teacher/dashboard` | Full table with filter + search |
| List of dicts + file storage | `tasks.json` via `load_tasks()` / `save_tasks()` |
| CRUD: Add + View | Core |
| CRUD: Delete + Update | Bonus — teacher can edit any record |
| Loops | `for t in tasks` for stats, filter, display |
| Functions | `load_tasks`, `save_tasks`, `get_stats`, `next_id` |
| Exception Handling | `try/except` on all file ops |
| Teacher Password | SHA-256 hashed, Flask session |

---

## 📊 Student Form Fields
1. Full Name
2. USN / Roll Number
3. Email Address
4. Phone Number
5. Semester
6. Section
7. Subject (dropdown)
8. Task Title
9. Description / Approach
10. Additional Notes
11. Status (Pending / In Progress / Completed)
12. Priority (Low / Medium / High)

---

## 🎯 Presentation Flow
`Student fills form → POST /student/submit → Saved to tasks.json`  
`Teacher logs in → /teacher/dashboard → Sees all records → Can filter/search/edit/delete`
