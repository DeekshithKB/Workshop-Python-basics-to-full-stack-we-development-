from flask import Flask, render_template, request, redirect, url_for, flash, session
import json, os, hashlib

app = Flask(__name__)
app.secret_key = "atom_workshop_secret_2024"

RECORD_FILE = "tasks.json"
TEACHER_PASSWORD = "atom2024"   # Change this to your preferred password

# ─── Helper: simple hash for session checks ──────────────────────────────────
def hash_pw(pw):
    return hashlib.sha256(pw.encode()).hexdigest()

TEACHER_HASH = hash_pw(TEACHER_PASSWORD)

# ─── Data Functions ───────────────────────────────────────────────────────────
def load_tasks():
    if os.path.exists(RECORD_FILE):
        try:
            with open(RECORD_FILE, "r") as f:
                return json.load(f)
        except (json.JSONDecodeError, IOError) as e:
            print(f"Error loading: {e}")
            return []
    return []

def save_tasks(tasks):
    try:
        with open(RECORD_FILE, "w") as f:
            json.dump(tasks, f, indent=4)
    except IOError as e:
        print(f"Error saving: {e}")

def get_stats(tasks):
    total = len(tasks)
    completed = sum(1 for t in tasks if t["status"] == "Completed")
    pending   = total - completed
    subjects  = {}
    for t in tasks:
        s = t.get("subject", "Other")
        subjects[s] = subjects.get(s, 0) + 1
    return {"total": total, "completed": completed, "pending": pending, "subjects": subjects}

def next_id(tasks):
    return max((t["id"] for t in tasks), default=0) + 1

# ─── Landing Page ─────────────────────────────────────────────────────────────
@app.route("/")
def landing():
    return render_template("landing.html")

# ─── STUDENT ROUTES ───────────────────────────────────────────────────────────
@app.route("/student")
def student():
    return render_template("student.html")

@app.route("/student/submit", methods=["POST"])
def student_submit():
    try:
        name        = request.form.get("name", "").strip()
        usn         = request.form.get("usn", "").strip()
        email       = request.form.get("email", "").strip()
        phone       = request.form.get("phone", "").strip()
        semester    = request.form.get("semester", "").strip()
        section     = request.form.get("section", "").strip()
        subject     = request.form.get("subject", "").strip()
        task        = request.form.get("task", "").strip()
        description = request.form.get("description", "").strip()
        priority    = request.form.get("priority", "Medium")
        status      = request.form.get("status", "Pending")
        notes       = request.form.get("notes", "").strip()

        if not all([name, usn, email, subject, task]):
            flash("Please fill in all required fields.", "error")
            return redirect(url_for("student"))

        tasks = load_tasks()
        record = {
            "id":          next_id(tasks),
            "name":        name,
            "usn":         usn,
            "email":       email,
            "phone":       phone,
            "semester":    semester,
            "section":     section,
            "subject":     subject,
            "task":        task,
            "description": description,
            "priority":    priority,
            "status":      status,
            "notes":       notes
        }
        tasks.append(record)
        save_tasks(tasks)
        flash(f"Task submitted successfully! Welcome, {name}.", "success")
        return redirect(url_for("student_success", name=name))
    except Exception as e:
        flash(f"Error: {e}", "error")
        return redirect(url_for("student"))

@app.route("/student/success")
def student_success():
    name = request.args.get("name", "Student")
    return render_template("student_success.html", name=name)

# ─── TEACHER ROUTES ───────────────────────────────────────────────────────────
@app.route("/teacher/login", methods=["GET", "POST"])
def teacher_login():
    if request.method == "POST":
        pw = request.form.get("password", "")
        if hash_pw(pw) == TEACHER_HASH:
            session["teacher"] = True
            flash("Welcome back, Teacher!", "success")
            return redirect(url_for("teacher_dashboard"))
        else:
            flash("Wrong password. Try again.", "error")
    return render_template("teacher_login.html")

@app.route("/teacher/logout")
def teacher_logout():
    session.pop("teacher", None)
    flash("Logged out successfully.", "success")
    return redirect(url_for("landing"))

def teacher_required(f):
    from functools import wraps
    @wraps(f)
    def decorated(*args, **kwargs):
        if not session.get("teacher"):
            flash("Please log in as teacher first.", "error")
            return redirect(url_for("teacher_login"))
        return f(*args, **kwargs)
    return decorated

@app.route("/teacher/dashboard")
@teacher_required
def teacher_dashboard():
    tasks = load_tasks()
    stats = get_stats(tasks)
    filter_status  = request.args.get("filter", "All")
    filter_subject = request.args.get("subject", "All")
    search         = request.args.get("search", "").strip().lower()

    filtered = tasks
    if filter_status != "All":
        filtered = [t for t in filtered if t["status"] == filter_status]
    if filter_subject != "All":
        filtered = [t for t in filtered if t.get("subject") == filter_subject]
    if search:
        filtered = [t for t in filtered if
                    search in t.get("name","").lower() or
                    search in t.get("usn","").lower() or
                    search in t.get("task","").lower()]

    subjects = list(stats["subjects"].keys())
    return render_template("teacher_dashboard.html",
                           tasks=filtered, stats=stats,
                           filter_status=filter_status,
                           filter_subject=filter_subject,
                           search=search, subjects=subjects)

@app.route("/teacher/delete/<int:task_id>")
@teacher_required
def teacher_delete(task_id):
    try:
        tasks = load_tasks()
        tasks = [t for t in tasks if t["id"] != task_id]
        save_tasks(tasks)
        flash("Record deleted.", "success")
    except Exception as e:
        flash(f"Error: {e}", "error")
    return redirect(url_for("teacher_dashboard"))

@app.route("/teacher/update/<int:task_id>", methods=["GET", "POST"])
@teacher_required
def teacher_update(task_id):
    tasks = load_tasks()
    task  = next((t for t in tasks if t["id"] == task_id), None)
    if not task:
        flash("Record not found.", "error")
        return redirect(url_for("teacher_dashboard"))

    if request.method == "POST":
        task["status"]   = request.form.get("status", task["status"])
        task["priority"] = request.form.get("priority", task["priority"])
        task["notes"]    = request.form.get("notes", "").strip()
        save_tasks(tasks)
        flash("Record updated.", "success")
        return redirect(url_for("teacher_dashboard"))

    return render_template("teacher_update.html", task=task)

if __name__ == "__main__":
    app.run(debug=True)
