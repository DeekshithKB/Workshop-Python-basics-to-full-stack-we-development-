// ── Form Validation ────────────────────────────────────────────────────────
document.addEventListener("DOMContentLoaded", function () {

    // Validate on submit
    const studentForm = document.getElementById("studentForm");
    if (studentForm) {
        studentForm.addEventListener("submit", function (e) {
            let ok = true;
            const required = studentForm.querySelectorAll("[required]");
            required.forEach(function (el) {
                const err = el.parentElement.querySelector(".field-error");
                if (!el.value.trim()) {
                    el.classList.add("invalid");
                    if (err) err.classList.add("show");
                    ok = false;
                } else {
                    el.classList.remove("invalid");
                    if (err) err.classList.remove("show");
                }
            });
            if (!ok) {
                e.preventDefault();
                // Scroll to first error
                const first = studentForm.querySelector(".invalid");
                if (first) first.scrollIntoView({ behavior: "smooth", block: "center" });
            }
        });

        // Clear error on input
        studentForm.querySelectorAll(".field-input").forEach(function (el) {
            el.addEventListener("input", function () {
                this.classList.remove("invalid");
                const err = this.parentElement.querySelector(".field-error");
                if (err) err.classList.remove("show");
            });
        });
    }

    // ── Auto-dismiss toasts ──────────────────────────────────────────────
    document.querySelectorAll(".toast").forEach(function (t) {
        setTimeout(function () {
            t.style.transition = "opacity .4s, transform .4s";
            t.style.opacity    = "0";
            t.style.transform  = "translateX(20px)";
            setTimeout(function () { t.remove(); }, 400);
        }, 3500);
    });

    // ── Animate progress bar ─────────────────────────────────────────────
    document.querySelectorAll(".progress-fill[data-w]").forEach(function (el) {
        const w = el.getAttribute("data-w");
        el.style.width = "0%";
        requestAnimationFrame(function () {
            setTimeout(function () { el.style.width = w + "%"; }, 150);
        });
    });

});

// ── Password toggle (teacher login) ───────────────────────────────────────
function togglePw() {
    const inp = document.getElementById("pwInput");
    if (inp) inp.type = inp.type === "password" ? "text" : "password";
}
